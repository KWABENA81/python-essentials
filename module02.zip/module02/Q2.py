from distlib.compat import raw_input

name = raw_input('Enter your name: ')
print('Hello ', name.capitalize())
