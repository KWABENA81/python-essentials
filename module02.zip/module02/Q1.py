from distlib.compat import raw_input

total = int(input('What is the total amount for your online shopping?'))
country = raw_input('Shipping within the US or Canada?')

if country.upper() == "US":
    if total <= 50:
        print("Shipping Costs $6.00")
    elif total <= 100:
        print("Shipping Costs $9.00")
    elif total <= 150:
        print("Shipping Costs $12.00")
    else:
        print("FREE")

if country.capitalize() == "Canada":
    if total <= 50:
        print("Shipping Costs $8.00")
    elif total <= 100:
        print("Shipping Costs $12.00")
    elif total <= 150:
        print("Shipping Costs $15.00")
    else:
        print("FREE")
